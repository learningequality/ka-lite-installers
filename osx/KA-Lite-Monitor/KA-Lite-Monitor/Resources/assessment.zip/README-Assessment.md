This is a dummy assessment.zip to make the build succeed.

Please download the right assessment.zip at https://learningequality.org/downloads/ka-lite/<version-code>/content/assessment.zip.  Example: https://learningequality.org/downloads/ka-lite/0.14/content/assessment.zip